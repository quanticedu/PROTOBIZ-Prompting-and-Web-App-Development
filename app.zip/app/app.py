from flask import Flask, render_template, request, redirect, url_for, session, flash
import secrets
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Configure session cookie settings
app.config.update(
    SESSION_COOKIE_SECURE=True,  # Set to True to include the Secure attribute
    SESSION_COOKIE_SAMESITE='None'  # Set to 'None' for SameSite=None
)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///english_learning_app.db'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(80), nullable=False)
    language_level = db.Column(db.String(10))  # beginning, intermediate, advanced

class Show(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)

class Clip(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    show_id = db.Column(db.Integer, db.ForeignKey('show.id'), nullable=False)
    language_level = db.Column(db.String(10))  # beginning, intermediate, advanced

    show = db.relationship('Show', backref=db.backref('clips', lazy=True))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']  # Consider hashing the password
        language_level = request.form['language_level']

        # Check if user already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Choose a different one.', 'danger')
            return redirect(url_for('signup'))

        new_user = User(username=username, password=password, language_level=language_level)
        db.session.add(new_user)
        db.session.commit()

        return redirect(url_for('home'))
    return render_template('signup.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']  # In a real app, this should be a hashed password

        # Query the database for the user
        user = User.query.filter_by(username=username).first()

        if user and user.password == password:
            # User exists and password matches
            session['username'] = username
            flash(f'Welcome back, {username}!', 'success')
            return redirect(url_for('home'))
        else:
            # User doesn't exist or password doesn't match
            flash('Invalid username or password. Please try again.', 'danger')

    return render_template('login.html')


@app.route('/logout')
def logout():
    # Clear the session data
    session.pop('username', None)
    return redirect(url_for('home'))
  
@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'username' not in session:
        flash('You need to log in to view this page', 'danger')
        return redirect(url_for('login'))

    username = session['username']
    user = User.query.filter_by(username=username).first()

    if request.method == 'POST':
        language_level = request.form['language_level']
        user.language_level = language_level
        db.session.commit()
        flash('Language level updated successfully!', 'success')
        return redirect(url_for('home'))

    return render_template('profile.html', user=user)

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if 'username' not in session or session['username'] != 'admin':
        flash('You need to be an admin to view this page', 'danger')
        return redirect(url_for('login'))

    if request.method == 'POST':
        if 'show_name' in request.form:
            # Adding a new show
            show_name = request.form['show_name']
            new_show = Show(name=show_name)
            db.session.add(new_show)
            db.session.commit()
            flash('New show added successfully!', 'success')
        elif 'clip_name' in request.form:
            # Adding a new clip
            clip_name = request.form['clip_name']
            show_id = request.form['show_id']
            language_level = request.form['language_level']
            new_clip = Clip(name=clip_name, show_id=show_id, language_level=language_level)
            db.session.add(new_clip)
            db.session.commit()
            flash('New clip added successfully!', 'success')

    shows = Show.query.all()
    clips = Clip.query.all()
    return render_template('admin.html', shows=shows, clips=clips)

@app.route('/search')
def search():
    if 'username' not in session:
        flash('You need to log in to view this page', 'danger')
        return redirect(url_for('login'))

    username = session['username']
    user = User.query.filter_by(username=username).first()

    if user:
        language_level = user.language_level
        matching_clips = Clip.query.filter_by(language_level=language_level).all()
        return render_template('search.html', clips=matching_clips)
    else:
        flash('User not found', 'danger')
        return redirect(url_for('home'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=8080, debug=True)